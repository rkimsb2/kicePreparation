package example.json;

import com.google.gson.Gson;

public class GsonFromJsonExample {
    static class Person {
        private String name;
        private int age;
        public Person(String name, int age) {
            this.name = name;
            this.age = age;
        }
    }
    public static void main(String[] args) {
        String json = "{\"name\":\"홍길동\",\"age\":25}";
        Gson gson = new Gson();

        Person person = gson.fromJson(json, Person.class);
        System.out.println(person.name);
        System.out.println(person.age);
    }
}
