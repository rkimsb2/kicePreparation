package example.json;

import com.google.gson.Gson;

import java.util.List;

public class JsonToObjectExample {
    class Subject {
        private String name;
        private String professor;

        public String getName() {
            return name;
        }

        public String getProfessor() {
            return professor;
        }
    }

    class StudentInfo {
        private long id;
        private List<String> students;
        private Subject subject;

        public long getId() {
            return id;
        }

        public List<String> getStudents() {
            return students;
        }

        public Subject getSubject() {
            return subject;
        }
    }

    public static void main(String[] args) {
        String json = "{\"id\":1,\"students\":[\"Anna\",\"Jerry\"],\"subject\":{\"name\":\"Java\",\"professor\":\"Tony\"}}";

        Gson gson = new Gson();
        StudentInfo studentInfo = gson.fromJson(json, StudentInfo.class);

        long id = studentInfo.getId();
        System.out.println("id: " + id);

        List<String> students = studentInfo.getStudents();
        for (String stu : students) {
            System.out.println(stu);
        }

        System.out.println(studentInfo.getSubject().getName());
    }
}
