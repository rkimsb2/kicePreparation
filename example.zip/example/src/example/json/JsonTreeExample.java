package example.json;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

public class JsonTreeExample {

    public static void main(String[] args) {
        String json = "{\"id\":1,\"students\":[\"Anna\",\"Jerry\"],\"subject\":{\"name\":\"Java\",\"professor\":\"Tony\"}}";
        JsonElement element = new JsonParser().parse(json);
        JsonObject object = element.getAsJsonObject();
        long id =  object.get("id").getAsLong();
        JsonArray jsonArray = object.get("students").getAsJsonArray();
        for(JsonElement stu : jsonArray){
            System.out.println(stu.getAsString());
        }
        JsonObject jsonObject = object.get("subject").getAsJsonObject();
        System.out.println(jsonObject.get("name").getAsString());
    }
}
