package example.json;

import com.google.gson.Gson;

public class GsonToJsonExample {
    static class Person {
        String name;
        int age;
        Person(String name, int age) {
            this.name = name;
            this.age = age;
        }
    }
    public static void main(String[] args) {
        Person person = new Person("홍길동", 25);
        Gson gson = new Gson();
        String json = gson.toJson(person);
        System.out.println(json);
    }
}
