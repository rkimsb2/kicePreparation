package example.jetty;

import org.eclipse.jetty.client.HttpClient;
import org.eclipse.jetty.client.api.ContentResponse;
import org.eclipse.jetty.client.util.StringContentProvider;
import org.eclipse.jetty.http.HttpHeader;

public class JettyHttpClientExample {
    public static void main(String[] args) throws Exception {
        HttpClient httpClient = new HttpClient();
        httpClient.start();

        String processed = "sample query";
        String json = String.format("{\"query\":\"%s\"}", processed);

        ContentResponse response = httpClient.POST("http://localhost:8080/hello")
                .header(HttpHeader.CONTENT_TYPE, "application/json")
                .content(new StringContentProvider(json), "application/json")
                .send();

        String responseBody =  response.getContentAsString();
        System.out.println("서버 응답: " + responseBody);

        httpClient.stop();
    }
}
